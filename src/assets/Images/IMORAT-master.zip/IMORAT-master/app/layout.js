import { metadata } from './metadata';

export { metadata };

import RootLayout from './RootLayout';

export default RootLayout;